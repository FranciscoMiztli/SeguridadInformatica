from django.apps import AppConfig


class GenpasswordConfig(AppConfig):
    name = 'genPassword'
