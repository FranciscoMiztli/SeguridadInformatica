from django.apps import AppConfig


class PortadaConfig(AppConfig):
    name = 'portada'
