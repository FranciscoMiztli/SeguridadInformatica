from django.apps import AppConfig


class TransposicionConfig(AppConfig):
    name = 'transposicion'
