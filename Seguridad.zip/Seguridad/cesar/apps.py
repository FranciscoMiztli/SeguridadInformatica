from django.apps import AppConfig


class CesarConfig(AppConfig):
    name = 'cesar'
